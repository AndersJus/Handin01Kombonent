/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dk.sdu.mmmi.cbse.collisionsystem;

import dk.sdu.mmmi.cbse.common.data.Entity;
import dk.sdu.mmmi.cbse.common.data.GameData;
import dk.sdu.mmmi.cbse.common.data.World;
import dk.sdu.mmmi.cbse.common.data.entityparts.PositionPart;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.platform.commons.function.Try.success;

/**
 *
 * @author Anders
 */
public class CollisionDetectorTest {
    Entity entity = new Entity();
    Entity entity2 = new Entity();
    Entity entity3 = new Entity();
    
    public CollisionDetectorTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        entity.setRadius(10);
        PositionPart pos = new PositionPart(100, 100, 0);
        entity.add(pos);
        
        
        entity2.setRadius(10);
        PositionPart pos1 = new PositionPart(105, 105, 0);
        entity2.add(pos1);
        
       
        entity3.setRadius(10);
        PositionPart pos2 = new PositionPart(200, 200, 0);
        entity3.add(pos2);
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of process method, of class CollisionDetector.
     */
    @org.junit.jupiter.api.Test
    public void testProcess() {
        
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of Collides method, of class CollisionDetector.
     */
    @org.junit.jupiter.api.Test
    public void testCollides() {
        System.out.println("Collides");
                
        CollisionDetector instance = new CollisionDetector();
        Boolean expResult = true;
        Boolean result = instance.Collides(entity, entity2);
        assertEquals(expResult, result);
               
        Boolean result1 = instance.Collides(entity, entity3);
        assertNotEquals(expResult, result1);
    }
    
}
